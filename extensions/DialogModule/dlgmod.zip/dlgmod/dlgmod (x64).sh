cd "${0%/*}"
clang++ -c -std=c++17 "Cocoa.part1.cpp" "main.cpp" "config.cpp" -fPIC -m64
clang++ -c -ObjC "Cocoa.part2.mm" "subclass.mm" -fPIC -m64
clang++ "Cocoa.part1.o" "Cocoa.part2.o" "subclass.o" "config.o" "main.o" -o "dlgmod (x64)/dlgmod" -framework Cocoa -fPIC -m64
chmod 777 "dlgmod (x64)/dlgmod"
